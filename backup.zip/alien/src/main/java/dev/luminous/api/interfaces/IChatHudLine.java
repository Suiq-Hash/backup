package dev.luminous.api.interfaces;

public interface IChatHudLine {
    int getMessageId();
    void setMessageId(int id);
}
