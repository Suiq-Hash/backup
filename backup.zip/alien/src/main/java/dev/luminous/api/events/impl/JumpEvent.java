package dev.luminous.api.events.impl;

import dev.luminous.api.events.Event;

public class JumpEvent extends Event {
    public JumpEvent(Stage stage) {
        super(stage);
    }
}
