package dev.luminous.api.events.impl;

public class MouseUpdateEvent {
}
