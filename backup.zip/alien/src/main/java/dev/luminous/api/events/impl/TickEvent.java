package dev.luminous.api.events.impl;

import dev.luminous.api.events.Event;

public class TickEvent extends Event {
    public TickEvent(Stage stage) {
        super(stage);
    }
}
