package dev.luminous.mod.modules.settings;

public enum Placement {
    Vanilla,
    Strict,
    Legit,
    AirPlace
}
