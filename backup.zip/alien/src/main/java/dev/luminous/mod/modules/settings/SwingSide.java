package dev.luminous.mod.modules.settings;

public enum SwingSide {
    All,
    Client,
    Server,
    None
}
