## License
GNU General Public License v3
## Credits
- https://github.com/coltonk9043/Aoba-MC-Hacked-Client
- https://github.com/qualterz/lookaround
- https://github.com/Pan4ur/ThunderHack-Recode
- https://github.com/Ladysnake/Satin
- https://github.com/MeteorDevelopment/meteor-client
- https://github.com/cabaletta/baritone
- https://github.com/The-Fireplace-Minecraft-Mods/In-Game-Account-Switcher
